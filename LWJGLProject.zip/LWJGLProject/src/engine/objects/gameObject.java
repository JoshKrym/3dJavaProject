package engine.objects;

import engine.Graphics.Material;
import engine.Graphics.Mesh;
import engine.Graphics.Vertex;
import engine.Maths.Vector2f;
import engine.Maths.Vector3f;

import static engine.Maths.TextureLocations.*;


public class gameObject {
    public Vector3f getPosition() {
        return position;
    }

    public Vector3f getRotation() {
        return rotation;
    }

    public Vector3f getScale() {
        return scale;
    }

    public Mesh getMesh() {
        return mesh;
    }

    public void setPosition(Vector3f position) {
        this.position = position;
    }

    private Vector3f position, rotation, scale;
    private String material;
    private Mesh mesh;


    public gameObject(Vector3f thisposition, Vector3f thisrotation, Vector3f thisscale, String materialName){
        position = thisposition;
        rotation=thisrotation;
        scale=thisscale;
        material=materialName;
        mesh = new Mesh(new Vertex[]{
                //Back face
                /*0*/new Vertex(new Vector3f(-0.5f,  0.5f, -0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[0] : Dirt[0]),//short on time
                /*1*/new Vertex(new Vector3f(-0.5f, -0.5f, -0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[1] : Dirt[1]),
                /*2*/new Vertex(new Vector3f( 0.5f, -0.5f, -0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[2] : Dirt[2]),
                /*3*/new Vertex(new Vector3f( 0.5f,  0.5f, -0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[3] : Dirt[3]),

                //Front face
                /*4*/new Vertex(new Vector3f(-0.5f,  0.5f,  0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[0] : Dirt[0]),
                /*5*/new Vertex(new Vector3f(-0.5f, -0.5f,  0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[1] : Dirt[1]),
                /*6*/new Vertex(new Vector3f( 0.5f, -0.5f,  0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[2] : Dirt[2]),
                /*7*/new Vertex(new Vector3f( 0.5f,  0.5f,  0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[3] : Dirt[3]),
                //speed this up by using 8 defined vector 3f variables, and then putting those in the different coordinate spots, could also speed up by using indices in situations in which the Vertexs are the exact same
                //Right face
                /*8*/new Vertex(new Vector3f( 0.5f,  0.5f, -0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[0] : Dirt[0]),
                /*9*/new Vertex(new Vector3f( 0.5f, -0.5f, -0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[1] : Dirt[1]),
                /*10*/new Vertex(new Vector3f( 0.5f, -0.5f,  0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[2] : Dirt[2]),
                /*11*/new Vertex(new Vector3f( 0.5f,  0.5f,  0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[3] : Dirt[3]),

                //Left face
                /*12*/new Vertex(new Vector3f(-0.5f,  0.5f, -0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[0] : Dirt[0]),
                /*13*/new Vertex(new Vector3f(-0.5f, -0.5f, -0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[1] : Dirt[1]),
                /*14*/new Vertex(new Vector3f(-0.5f, -0.5f,  0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[2] : Dirt[2]),
                /*15*/new Vertex(new Vector3f(-0.5f,  0.5f,  0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassSide[3] : Dirt[3]),

                //Top face
                /*16*/new Vertex(new Vector3f(-0.5f,  0.5f,  0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassTop[0] : Dirt[0]),
                /*17*/new Vertex(new Vector3f(-0.5f,  0.5f, -0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassTop[1] : Dirt[1]),
                /*18*/new Vertex(new Vector3f( 0.5f,  0.5f, -0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassTop[2] : Dirt[2]),
                /*19*/new Vertex(new Vector3f( 0.5f,  0.5f,  0.5f),new Vector3f(0,  0, 0), (material.equals("grass")) ? grassTop[3] : Dirt[3]),

                //Bottom face
                /*20*/new Vertex(new Vector3f(-0.5f, -0.5f,  0.5f),new Vector3f(0,  0, 0), Dirt[0]),
                /*21*/new Vertex(new Vector3f(-0.5f, -0.5f, -0.5f),new Vector3f(0,  0, 0), Dirt[1]),
                /*22*/new Vertex(new Vector3f( 0.5f, -0.5f, -0.5f),new Vector3f(0,  0, 0), Dirt[2]),
                /*23*/new Vertex(new Vector3f( 0.5f, -0.5f,  0.5f),new Vector3f(0,  0, 0), Dirt[3])
        }, new int[] {
                //Back face
                0, 1, 3,
                3, 1, 2,

                //Front face
                4, 5, 7,
                7, 5, 6,

                //Right face
                8, 9, 11,
                11, 9, 10,

                //Left face
                12, 13, 15,
                15, 13, 14,

                //Top face
                16, 17, 19,
                19, 17, 18,

                //Bottom face
                20, 21, 23,
                23, 21, 22
        }, new Material("/resources/textures/Textures.png"));
        mesh.create();
    }


    /*public void update(){
        temp +=0.02;
        position.setX((float)Math.sin(temp));
        rotation.set((float)Math.sin(temp)*360,(float)Math.sin(temp)*360,(float)Math.sin(temp)*360);
        scale.set((float)Math.sin(temp), (float)Math.sin(temp), (float)Math.sin(temp));
        position.setZ(position.getZ()- (float)Math.sin(temp));
    }*/

}
