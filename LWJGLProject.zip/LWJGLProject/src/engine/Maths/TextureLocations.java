package engine.Maths;

public class TextureLocations {
    private static float Unit= 0.0625f;
    public static Vector2f[] grassSide = {new Vector2f(0.0f,0.0f), new Vector2f(0.0f,Unit), new Vector2f(Unit,Unit), new Vector2f(Unit,0.0f)};
    public static Vector2f[] grassTop = {new Vector2f(Unit,0.0f), new Vector2f(Unit,Unit), new Vector2f(2.0f*Unit,Unit), new Vector2f(2.0f*Unit,0.0f)};
    public static Vector2f[] Dirt = {new Vector2f(2.0f*Unit,0.0f), new Vector2f(2.0f*Unit,Unit), new Vector2f(3.0f*Unit,Unit), new Vector2f(3.0f*Unit,0.0f)};
}
