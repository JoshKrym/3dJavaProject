package engine.io;

import org.lwjgl.glfw.*;

public class Input {
    public static double getMouseX() {
        return mouseX;
    }//getter methods for input

    public static double getMouseY() {
        return mouseY;
    }

    public static double getScrollX() {
        return scrollX;
    }

    public static double getScrollY() {
        return scrollY;
    }

    public GLFWKeyCallback getKeyboardCallback() {
        return keyboard;
    }//getter methods for checking inputs

    public GLFWCursorPosCallback getMouseMoveCallback() {
        return mouseMove;
    }

    public GLFWMouseButtonCallback getMouseButtonsCallback() {
        return mouseButtons;
    }
    public GLFWScrollCallback getMouseScrollCallback() {
        return mouseScroll;
    }

    public static boolean isKeyDown(int key){
        return keys[key];
    }//return whether or not a specified key was pressed
    public static boolean isButtonDown(int button){
        return buttons[button];
    }//as above but for mouse
    public void destroy(){//method for destroying all of our callbacks
        keyboard.free();
        mouseMove.free();
        mouseButtons.free();
        mouseScroll.free();
    }
    private static boolean[] keys=new boolean[GLFW.GLFW_KEY_LAST];//creates a boolean for if the key was pressed i think
    private static boolean[] buttons=new boolean[GLFW.GLFW_MOUSE_BUTTON_LAST];//as above for mousebuttons
    private static double mouseX,mouseY;//location of mouse
    private static double scrollX, scrollY;//how much have i scrolled

    private GLFWKeyCallback keyboard;//callbacks
    private GLFWCursorPosCallback mouseMove;
    private GLFWMouseButtonCallback mouseButtons;
    private GLFWScrollCallback mouseScroll;

    public Input() {
        keyboard = new GLFWKeyCallback() {
            @Override
            public void invoke(long window, int key, int scancode, int action, int mods) {
                keys[key]= action!=GLFW.GLFW_RELEASE;
            }
        };
        mouseMove = new GLFWCursorPosCallback() {
            @Override
            public void invoke(long window, double xpos, double ypos) {
                mouseX=xpos;
                mouseY=ypos;
            }
        };
        mouseButtons = new GLFWMouseButtonCallback() {
            @Override
            public void invoke(long window, int button, int action, int mods) {
                buttons[button]= action!=GLFW.GLFW_RELEASE;
            }
        };
        mouseScroll = new GLFWScrollCallback(){
            @Override
            public void invoke(long window, double xoffset, double yoffset) {
                scrollX+=xoffset;
                scrollY+=yoffset;
            }
        };
    }
}