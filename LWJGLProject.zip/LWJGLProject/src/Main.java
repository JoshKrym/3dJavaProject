import engine.Graphics.*;
import engine.Maths.Vector2f;
import engine.Maths.Vector3f;
import engine.io.Input;
import engine.io.Window;
import engine.objects.Camera;
import engine.objects.gameObject;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.util.ArrayList;

public class Main implements Runnable{
    public Thread game;//declaring a new thread to host our game in
    public Window window;//creating a new window of our created Window Class
    public Shader shader;
    public Renderer renderer;
    public final int WIDTH= 1280, HEIGHT=720;//declaring height and width as final as this is the resolution and it will not change
    private static String mat = "dirt";

    /*public Mesh mesh = new Mesh(new Vertex[]{
            //Back face
            new Vertex(new Vector3f(-0.5f,  0.5f, -0.5f),new Vector3f(0,  0, 0), new Vector2f(0.0f, 0.0f)),
            new Vertex(new Vector3f(-0.5f, -0.5f, -0.5f),new Vector3f(0,  0, 0), new Vector2f(0.0f, 1.0f)),
            new Vertex(new Vector3f( 0.5f, -0.5f, -0.5f),new Vector3f(0,  0, 0), new Vector2f(1.0f, 1.0f)),
            new Vertex(new Vector3f( 0.5f,  0.5f, -0.5f),new Vector3f(0,  0, 0), new Vector2f(1.0f, 0.0f)),

            //Front face
            new Vertex(new Vector3f(-0.5f,  0.5f,  0.5f),new Vector3f(0,  0, 0), new Vector2f(0.0f, 0.0f)),
            new Vertex(new Vector3f(-0.5f, -0.5f,  0.5f),new Vector3f(0,  0, 0), new Vector2f(0.0f, 1.0f)),
            new Vertex(new Vector3f( 0.5f, -0.5f,  0.5f),new Vector3f(0,  0, 0), new Vector2f(1.0f, 1.0f)),
            new Vertex(new Vector3f( 0.5f,  0.5f,  0.5f),new Vector3f(0,  0, 0), new Vector2f(1.0f, 0.0f)),

            //Right face
            new Vertex(new Vector3f( 0.5f,  0.5f, -0.5f),new Vector3f(0,  0, 0), new Vector2f(0.0f, 0.0f)),
            new Vertex(new Vector3f( 0.5f, -0.5f, -0.5f),new Vector3f(0,  0, 0), new Vector2f(0.0f, 1.0f)),
            new Vertex(new Vector3f( 0.5f, -0.5f,  0.5f),new Vector3f(0,  0, 0), new Vector2f(1.0f, 1.0f)),
            new Vertex(new Vector3f( 0.5f,  0.5f,  0.5f),new Vector3f(0,  0, 0), new Vector2f(1.0f, 0.0f)),

            //Left face
            new Vertex(new Vector3f(-0.5f,  0.5f, -0.5f),new Vector3f(0,  0, 0), new Vector2f(0.0f, 0.0f)),
            new Vertex(new Vector3f(-0.5f, -0.5f, -0.5f),new Vector3f(0,  0, 0), new Vector2f(0.0f, 1.0f)),
            new Vertex(new Vector3f(-0.5f, -0.5f,  0.5f),new Vector3f(0,  0, 0), new Vector2f(1.0f, 1.0f)),
            new Vertex(new Vector3f(-0.5f,  0.5f,  0.5f),new Vector3f(0,  0, 0), new Vector2f(1.0f, 0.0f)),

            //Top face
            new Vertex(new Vector3f(-0.5f,  0.5f,  0.5f),new Vector3f(0,  0, 0), new Vector2f(0.0f, 0.0f)),
            new Vertex(new Vector3f(-0.5f,  0.5f, -0.5f),new Vector3f(0,  0, 0), new Vector2f(0.0f, 1.0f)),
            new Vertex(new Vector3f( 0.5f,  0.5f, -0.5f),new Vector3f(0,  0, 0), new Vector2f(1.0f, 1.0f)),
            new Vertex(new Vector3f( 0.5f,  0.5f,  0.5f),new Vector3f(0,  0, 0), new Vector2f(1.0f, 0.0f)),

            //Bottom face
            new Vertex(new Vector3f(-0.5f, -0.5f,  0.5f),new Vector3f(0,  0, 0), new Vector2f(0.0f, 0.0f)),
            new Vertex(new Vector3f(-0.5f, -0.5f, -0.5f),new Vector3f(0,  0, 0), new Vector2f(0.0f, 1.0f)),
            new Vertex(new Vector3f( 0.5f, -0.5f, -0.5f),new Vector3f(0,  0, 0), new Vector2f(1.0f, 1.0f)),
            new Vertex(new Vector3f( 0.5f, -0.5f,  0.5f),new Vector3f(0,  0, 0), new Vector2f(1.0f, 0.0f)),
    }, new int[] {
            //Back face
            0, 1, 3,
            3, 1, 2,

            //Front face
            4, 5, 7,
            7, 5, 6,

            //Right face
            8, 9, 11,
            11, 9, 10,

            //Left face
            12, 13, 15,
            15, 13, 14,

            //Top face
            16, 17, 19,
            19, 17, 18,

            //Bottom face
            20, 21, 23,
            23, 21, 22
    }, new Material("/resources/textures/grass.png"));*/

    //public gameObject object;
    //public gameObject object1;

    ArrayList<gameObject> objects = new ArrayList<>();

    //public gameObject[] objects = new gameObject[529];

    public Camera camera = new Camera(new Vector3f(0,0,0), new Vector3f(0/*3.14f*/,0/*3.14f*/,0/*3.14f*/));

    public void start(){//method to start the game
        game = new Thread(this,"game");//instantiating our new thread
        game.start();//starting the new thread
    }
    public void init(){//put game objects here
        System.out.println("Initializing");//just so I can see
        window = new Window(WIDTH, HEIGHT, "Not Minecraft");//using our window constructor adding our width and height variables and giving the window a title
        shader = new Shader("/resources/shaders/mainVertex.glsl", "/resources/shaders/mainFragment.glsl");
        renderer = new Renderer(window, shader);
        window.setBackgroundColor(0.527f, 0.805f ,0.918f);//rgb for setting background color using method we created in window class
        //window.setFullscreen(true);
        window.create();//creating our window using the method we created in window class
        //object = new gameObject(new Vector3f(0,20,0), new Vector3f(0,0,0),new Vector3f(1,1,1), "grass");
        //object1 = new gameObject(new Vector3f(0,0,0), new Vector3f(0,0,0),new Vector3f(1,1,1));
        shader.create();
        //objects.add(object);

        for (int i=0; i<16; i++){
            for(int j=0; j<16; j++) {
                int n=0;
                for(int k=(int)(Math.random()*4)+1; k>=0; k--) {
                    if(n==0) objects.add(new gameObject(new Vector3f(i, k, j), new Vector3f(0, 0, 0), new Vector3f(1, 1, 1), "grass"));
                    else objects.add(new gameObject(new Vector3f(i, k, j), new Vector3f(0, 0, 0), new Vector3f(1, 1, 1), "dirt"));
                    System.out.println(n);
                    n++;
                }
                //System.out.println(n);
                //n++;
            }
        }
    }
    private void update(){
        //System.out.println("updating");
        window.update();// using the update method to update our window using the method we created in window class
        /*for(int i=1; i<objects.size(); i++){
            if(camera.getPosition().getX()==objects.get(i).getPosition().getX()-0.5) camera.setCanMove(0, false);
            if(camera.getPosition().getX()==objects.get(i).getPosition().getX()+0.5) camera.setCanMove(1, false);
            if(camera.getPosition().getX()==objects.get(i).getPosition().getX()-0.5) camera.setCanMove(2, false);
            if(camera.getPosition().getX()==objects.get(i).getPosition().getX()-0.5) camera.setCanMove(3, false);
            if(camera.getPosition().getX()==objects.get(i).getPosition().getX()-0.5) camera.setCanMove(4, false);
            if(camera.getPosition().getX()==objects.get(i).getPosition().getX()-0.5) camera.setCanMove(5, false);
        }*/
        if(Input.isKeyDown(GLFW.GLFW_KEY_1)) mat="dirt";
        else if(Input.isKeyDown(GLFW.GLFW_KEY_2)) mat="grass";
        if(Input.isButtonDown(GLFW.GLFW_MOUSE_BUTTON_RIGHT)){
            ArrayList<Integer> objectnumbers = new ArrayList<>();
            Vector3f cameraRotation=camera.getRotation();
            /*float Px =(float)(Math.sin(Math.toRadians(cameraRotation.getY()))) * 6;
            float Py =(float)(Math.sin(Math.toRadians(cameraRotation.getX()))) * 6;
            float Pz =(float)(Math.cos(Math.toRadians(cameraRotation.getY()))) * 6;*/
            int originalObjectsSize=objects.size();
            //System.out.println(originalObjectsSize);
            //float xline = camera.getPosition().getX()+(float)Math.sin(Math.toRadians(cameraRotation.getX()))*((objects.get(i).getPosition().getY()-camera.getPosition().getY())/camera.getRotation().getY())
            for(int i=1; i<originalObjectsSize;i++){
                float objectX = objects.get(i).getPosition().getX();
                float objectY = objects.get(i).getPosition().getY();
                float objectZ = objects.get(i).getPosition().getZ();
                float a=Math.abs(camera.getPosition().getY()-objects.get(i).getPosition().getY());
                float bx=Math.abs(camera.getPosition().getX()-objectX);
                float bz=Math.abs(camera.getPosition().getZ()-objectZ);
                float objDistanceX=(float)Math.sqrt(a*a+bx*bx);
                float objDistanceZ=(float)Math.sqrt(a*a+bz*bz);
                float Px =(float)(Math.sin(Math.toRadians(cameraRotation.getY()))) * bx;
                float Py =(float)(Math.toRadians(cameraRotation.getX())) *a;
                float Pz =(float)(Math.cos(Math.toRadians(cameraRotation.getY()))) * bz;
                Vector3f ray = Vector3f.add(camera.getPosition(), new Vector3f(-Px,Py,-Pz));
                System.out.println(ray.getX()+","+ray.getY()+","+ray.getZ());
                if(((ray.getX()>(objectX-0.5))&&ray.getX()<(objectX+0.5))&&((ray.getZ()>(objectZ-0.5))&&ray.getZ()<(objectZ+0.5))&&((ray.getY()>(objectY-0.5))&&ray.getY()<(objectY+0.5))){
                    System.out.println("Success\nObject: " + objectX +","+ objectY+","+ objectZ);
                    objectnumbers.add(i);
                    //findGreatest
                    gameObject comp=objects.get(objectnumbers.get(0));
                    for(int j=1; j<objectnumbers.size(); j++){//finding the object with the largest y
                        gameObject comp2=objects.get(objectnumbers.get(j));
                        if(comp2.getPosition().getY()>comp.getPosition().getY()){
                            comp=comp2;
                        }
                    }
                    //System.out.println(i);
                    objects.add(new gameObject(Vector3f.add(new Vector3f(0,1,0),comp.getPosition()), new Vector3f(0, 0, 0), new Vector3f(1, 1, 1), mat));
                    long tempTime= LocalTime.now().toNanoOfDay()+10000;
                    while(LocalTime.now().toNanoOfDay()<=tempTime);
                }
                /*float slope = ((objects.get(i).getPosition().getY()-camera.getPosition().getY())/(float)(Math.toRadians(cameraRotation.getX())));
                float xLine = camera.getPosition().getX()-(float)(Math.sin(Math.toRadians(cameraRotation.getY())))*slope;
                float zLine= camera.getPosition().getZ()-(float)(Math.cos(Math.toRadians(cameraRotation.getY())))*slope;//one of these is off
                System.out.println(xLine+" "+ zLine);
                float objectX = objects.get(i).getPosition().getX();
                float objectZ = objects.get(i).getPosition().getZ();
                System.out.println(objectX+" "+objectZ);
                if((xLine>(objectX-0.5)&&xLine<(objectX+0.5))&&(zLine>(objectZ-0.5)&&zLine<(objectZ+0.5))){//
                    objectnumbers.add(i);
                    //findGreatest
                    gameObject comp=objects.get(objectnumbers.get(0));
                    for(int j=1; j<objectnumbers.size(); j++){//finding the object with the largest y
                        gameObject comp2=objects.get(objectnumbers.get(j));
                        if(comp2.getPosition().getY()>comp.getPosition().getY()){
                            comp=comp2;
                        }
                    }
                    //System.out.println(i);
                    objects.add(new gameObject(Vector3f.add(new Vector3f(0,1,0),comp.getPosition()), new Vector3f(0, 0, 0), new Vector3f(1, 1, 1), mat));
                    //Vector3f newObjectPosition=Vector3f.add(new Vector3f(0,1,0),objects.get(objects.size()-1).getPosition());
                    //objects.get(objects.size()-1).setPosition(newObjectPosition);
                }
            */}
            //Vector3f placeDistance=Vector3f.add((camera.getPosition()).toInt(), new Vector3f((float)(int)((Math.sin(Math.toRadians(cameraRotation.getY()))) * -6), (float)(int)((Math.sin(Math.toRadians(cameraRotation.getX()))) * 6), (float)(int)((Math.cos(Math.toRadians(cameraRotation.getY()))) * -6)));
            //objects.add(new gameObject(placeDistance, new Vector3f(0,0,0),new Vector3f(1,1,1)));
        }
        //object.update();
        camera.update();

        /*if(Input.isButtonDown(GLFW.GLFW_MOUSE_BUTTON_LEFT)) System.out.println("x: "+ Input.getScrollX() + "\ny: "+Input.getScrollY());//using methods in created in Input class that detect when the left mouse button is pressed and print the mouse scrolling to screen. I think I messed this up, but as long as I understand it that is fine
        if(Input.isButtonDown(GLFW.GLFW_MOUSE_BUTTON_RIGHT)) window.setBackgroundColor((float)(Math.random()), (float)(Math.random()) ,(float)(Math.random()));//I just did this for fun:)*/
        /*frames++;
        if(System.currentTimeMillis()>time+1000){
        System.out.println(frames);
        time = System.currentTimeMillis();
        frames=0;}
        if(Input.isButtonDown(GLFW.GLFW_MOUSE_BUTTON_LEFT)){
            System.out.println("x: "+ Input.getMouseX() + "\ny: "+Input.getMouseY());
        }*/
    }
    private void close(){
        window.destroy();
        //object.getMesh().destroy();
        for(int i=1; i< objects.size(); i++){
            objects.get(i).getMesh().destroy();
        }
        shader.destroy();
    }
    private void render(){//method for rendering what is in the update method above to the frame
        //System.out.println("rendering");
        for(int i=1; i< objects.size(); i++){
            //if()
            renderer.renderMesh(objects.get(i), camera);
            //System.out.println(i);
        }
        //renderer.renderMesh(object, camera);
        window.swapBuffers();//tells the computer to show the next frame of an the application
    }
    public void run(){//this is what the thread we created will run. All threads need a run method to go with them. This is why we implement the runnable inteface
        init();//call the init method
        while(!window.shouldClose() && !Input.isKeyDown(GLFW.GLFW_KEY_ESCAPE)){//while return value from shouldClose method we created in window class is false or is keydown method from input class created is false, keep updating the frames and rendering them
            update();//update method created in this class
            render();//render method created in this class
            if(Input.isKeyDown(GLFW.GLFW_KEY_F11)) window.setFullscreen(!window.isFullscreen());//as before using iskeydown method from input class to check if f11 is pressed, if it is, then do the opposite of whatever fullscreen boolean already is from window object. IE. if window object is not fullscreen, set boolean for fullscreen to true, and make fullscreen, or the opposite\
            if(Input.isButtonDown(GLFW.GLFW_MOUSE_BUTTON_LEFT)) window.mouseState(true);
        }
        close();
        //calling method for destroying the window we created in window class, when the program finishes from window object.
    }
    public static void main(String[] args){
        new Main().start();
    }//creating main class object and starting thread
}
