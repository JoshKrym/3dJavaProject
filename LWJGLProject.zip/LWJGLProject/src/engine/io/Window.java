package engine.io;

import engine.Maths.Matrix4f;
import engine.Maths.Vector3f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.glfw.GLFWWindowSizeCallback;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;

public class Window {
    private int width, height;//creating variable characteristics for our window. Height and width
    private String title;//title for window
    private long Window;//window is stored in a long because of the conversion from c to java. I don't really get it
    public Input input;//Creating an input object from our input class
    /*private float backgroundR;//floats for rgb
    private float backgroundG;
    private float backgroundB;*/
    private Vector3f backgroundRGB = new Vector3f(0,0,0);
    private boolean isResized;//boolean that we use when the frame is resized
    private int[] windowPosX = new int[1], windowPosY = new int[1];//window position x and y, I don't understand the point of a 1 one size array, however, I think it is needed for the glfwGetWindowPos

    public Matrix4f getProjectionMatrix() {
        return projection;
    }

    private Matrix4f projection;

    public int getWidth() {
        return width;
    }//getter method for width of window

    public int getHeight() {
        return height;
    }//getter method for height of window

    public String getTitle() {
        return title;
    }//getter method for title of window

    public long getWindow() {
        return Window;
    }//getter method for long of window

    public void mouseState(boolean lock){
        GLFW.glfwSetInputMode(Window, GLFW.GLFW_CURSOR, lock ? GLFW.GLFW_CURSOR_DISABLED : GLFW.GLFW_CURSOR_NORMAL);
    }

    public void setFullscreen(boolean thefullscreen) {//method for Fullscreening window
        isFullscreen = thefullscreen;//sets the fullscreen boolean for window to whatever we set it to above
        isResized=true;//says that we have resized the window, made it true
        if (isFullscreen){//if the isFullscreen bool is true
            GLFW.glfwGetWindowPos(Window, windowPosX, windowPosY);//gets the position of the window
            GLFW.glfwSetWindowMonitor(Window,GLFW.glfwGetPrimaryMonitor()/*fullscreen*/, 0, 0, width, height, 0);//sets size, which window, fullscreen, position, refreshRate as well. GLFW.glfwGetPrimaryMonitor() sets the monitor to fullscreen when used in this method
        }
        else{//if not
            GLFW.glfwSetWindowMonitor(Window, 0/*fullscreen*/, windowPosX[0], windowPosY[0], width, height, 0);//don't full screen
        }
    }

    public boolean isFullscreen() {//getter method for fullscreen boolean
        return isFullscreen;//getter method for fullscreen boolean
    }

    private boolean isFullscreen;//fullscreen boolean
    public int frames;//stores frames per second
    private static long time;//stores time as variable
    private GLFWWindowSizeCallback sizeCallback;//I think this is what converts our long variable to the integer form that we can read
    //private float backgroundA;
    public Window(int theWidth, int theHeight, String theTitle){//constructor for our window
        width= theWidth;
        height = theHeight;
        title = theTitle;
        projection = Matrix4f.projection(70.0f, (float) width/(float) height, 0.1f, 1000.0f);
    }
    public void create(){//initializing our window method
        if(!GLFW.glfwInit()){//if the window was not initialized show an error
            System.err.println("GLFW was not initialized stupid!!!");
            return;
        }

        input = new Input();//new input object
        Window = GLFW.glfwCreateWindow(width, height, title, isFullscreen ? GLFW.glfwGetPrimaryMonitor() : 0, 0);//using glfw method to create a window with characteristics. I think it checks to see if monitor is fullscreen or not or maybe if fullscreen is true, ask mrs fournier
        time=System.currentTimeMillis();//this sets our time to the number of milliseconds since the start of 1970
        if(Window==0){//if there is no window, something obviously went wrong.
            System.err.println("Window wasn't created stupid");
            return;
        }
        GLFWVidMode videomode= GLFW.glfwGetVideoMode(GLFW.glfwGetPrimaryMonitor());//sets the video mode to the characteristics oif our monitor i think
        windowPosX[0]=(videomode.width()-width)/2;//sets the window position to the monitor width - the desired width divided by 2
        windowPosY[0]=(videomode.height()-height)/2;
        GLFW.glfwSetWindowPos(Window,windowPosX[0] , windowPosY[0]);//sets the position of the upper left corner of the window to put window in center of screen
        GLFW.glfwMakeContextCurrent(Window);//puts the window in the thread we created, I think
        GL.createCapabilities();//creates an instance of createCapabilities in thread. I don't know what it does, but it is necessary for window
        GL11.glEnable(GL11.GL_DEPTH_TEST);//creates a depth test. This is needed for 3d games

        createCallbacks();//use the create callbacks method of this class

        GLFW.glfwShowWindow(Window);//show the window to the screen
        GLFW.glfwSwapInterval(1);//sets the target frame rate to 60fps
    }
    private void createCallbacks(){//method for creating callbacks
        sizeCallback = new GLFWWindowSizeCallback() {//abstract class gets size on monitor and sets our size to it.
            @Override
            public void invoke(long window, int w, int h) {//overriden method we need
                width=w;
                height=h;
                isResized =true;//just sets that we resized the window to true
            }
        };

        GLFW.glfwSetKeyCallback(Window, input.getKeyboardCallback());//makes the window aware of different input methods and allows it to check for them.
        GLFW.glfwSetCursorPosCallback(Window, input.getMouseMoveCallback());
        GLFW.glfwSetMouseButtonCallback(Window, input.getMouseButtonsCallback());
        GLFW.glfwSetScrollCallback(Window, input.getMouseScrollCallback());
        GLFW.glfwSetWindowSizeCallback(Window, sizeCallback);//above
    }
    public void update(){//update method for our window
        if(isResized) {//if the window is resized
            GL11.glViewport(0,0,width,height);//change the size on the monitor
            isResized=false;}//set the is resized to false so it doesn't do this all the time
        GL11.glClearColor(backgroundRGB.getX(),backgroundRGB.getY(),backgroundRGB.getZ(), 1.0f);//sets the background variables rgb value
        GL11.glClear(GL11.GL_COLOR_BUFFER_BIT| GL11.GL_DEPTH_BUFFER_BIT);//sets the background to the variables
        GLFW.glfwPollEvents();//checks for all of the callbacks
        /*s++;//fps stuff
        if(System.currentTimeMillis()>time+1000){
            System.out.println(frames);
            time = System.currentTimeMillis();
            frames=0;}*/
    }
    public boolean shouldClose(){//close window on call of this function
        return GLFW.glfwWindowShouldClose(Window);
    }
    public void swapBuffers(){//method to swap buffers of window
        GLFW.glfwSwapBuffers(Window);//buffers are a queue, this removes one buffer from the queue
    }
    public void destroy(){//method for destroying our window
        input.destroy();//uses destroy method from input
        sizeCallback.free();//frees our callbacks size, or deletes it so it isn't checking for a window that isn't there
        GLFW.glfwWindowShouldClose(Window);//closes the window
        GLFW.glfwDestroyWindow(Window);//no more callbacks will be called for this window
        GLFW.glfwTerminate();//destroys anything else created by the glfw functions
    }
    public void setBackgroundColor(float r, float g, float b){//setter method for background colors
        backgroundRGB.setX(r);
        backgroundRGB.setY(g);
        backgroundRGB.setZ(b);
        /*backgroundR = r;
        backgroundG = g;
        backgroundB = b;*/
    }
}
