package engine.Maths;

public class Vector3f {
    public float getX() {
        return x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getY() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }

    public float getZ() {
        return z;
    }

    public void setZ(float z) {
        this.z = z;
    }

    private float x, y, z;

    public void set(float ax, float ay, float az){
    x=ax;
    y=ay;
    z=az;
}

    public Vector3f(float ax, float ay, float az){
        x=ax; y=ay; z=az;
    }

    /*public void add(float ax, float ay, float az){
        x+=ax;
        y+=ay;
        z+=az;
    }*/
    public static Vector3f add(Vector3f vector1, Vector3f vector2){
        return new Vector3f(vector1.getX()+vector2.getX(), vector1.getY()+vector2.getY(),vector1.getZ()+vector2.getZ());
    }
    public static Vector3f subtraction(Vector3f vector1, Vector3f vector2){
        return new Vector3f(vector1.getX()-vector2.getX(), vector1.getY()-vector2.getY(),vector1.getZ()-vector2.getZ());
    }
    public static Vector3f multiply(Vector3f vector1, Vector3f vector2){
        return new Vector3f(vector1.getX()*vector2.getX(), vector1.getY()*vector2.getY(),vector1.getZ()*vector2.getZ());
    }
    public static Vector3f divide(Vector3f vector1, Vector3f vector2){
        return new Vector3f(vector1.getX()/vector2.getX(), vector1.getY()/vector2.getY(),vector1.getZ()/vector2.getZ());
    }
    public Vector3f toInt(){
        return new Vector3f((float)((int)(this.getX())),(float)((int)(this.getY())),(float)((int)(this.getZ())));
    }

    public static float length(Vector3f vector){
        return (float)Math.sqrt(vector.getX()*vector.getX()+vector.getY()*vector.getY()+vector.getZ()*vector.getZ());
    }

    public static Vector3f normalize(Vector3f vector){
        float len = Vector3f.length(vector);
        return Vector3f.divide(vector, new Vector3f(len,len,len));
    }

    public static float dot(Vector3f vector1, Vector3f vector2){
        return vector1.getX()*vector2.getX()+vector1.getY()*vector2.getY()+vector1.getZ()*vector2.getZ();
    }

    @Override
    public int hashCode(){//used for hashmaps. A way of getting a separate integer for same values. i.e. different classes same values return the same thing. Says if you can compare
        final int prime=31;
        int result=1;
        result=prime*result+Float.floatToIntBits(x);
        result=prime*result+Float.floatToIntBits(y);
        result=prime*result+Float.floatToIntBits(z);
        return result;
    }

    @Override
    public boolean equals(Object obj){//equals says if one vector object can equal another vector object
        if(this==obj) return true;
        if(obj==null) return false;
        if(getClass()!= obj.getClass()) return false;
        Vector3f other = (Vector3f) obj;
        if(Float.floatToIntBits(x)!=Float.floatToIntBits(other.x)) return false;
        if(Float.floatToIntBits(y)!=Float.floatToIntBits(other.y)) return false;
        if(Float.floatToIntBits(z)!=Float.floatToIntBits(other.z)) return false;
        return true;
    }
}
