package engine.Graphics;

import engine.Maths.*;

public class Vertex {
    public Vector3f getPosition() {
        return position;
    }

    private Vector3f position, color;
    private Vector2f textureCoord;
    public Vertex(Vector3f thisPosition, Vector3f thisColor, Vector2f thisTextureCoord){
        position=thisPosition;
        color=thisColor;
        textureCoord=thisTextureCoord;
    }

    public Vector3f getColor() {
        return color;
    }
    public Vector2f getTextureCoord() {
        return textureCoord;
    }
}
