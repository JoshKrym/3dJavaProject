package engine.objects;

import engine.Maths.Vector3f;
import engine.io.Input;
import org.lwjgl.glfw.GLFW;

public class Camera {
    public Vector3f getPosition() {
        return position;
    }

    public Vector3f getRotation() {
        return rotation;
    }

    private Vector3f position, rotation;
    private float moveSpeed=0.05f, mouseSensitivity=0.3f;
    private double oldMouseX=0, oldMouseY=0, newMouseX, newMouseY;

    public boolean[] getCanMove() {
        return canMove;
    }

    public void setCanMove(int index, boolean canMove) {
        this.canMove[index] = canMove;
    }

    private boolean[] canMove={true,true,true,true,true,true};//0l,1r,2u,3d,4f,5b
    public Camera(Vector3f thisPosition, Vector3f thisRotation){
        position=thisPosition;
        rotation=thisRotation;
    }
    public void update(){

        //position = Vector3f.add(position, new Vector3f(0,-0.01f,0));

        newMouseX=Input.getMouseX();
        newMouseY=Input.getMouseY();
        //System.out.println(rotation.getX());

        float x =(float)(Math.sin(Math.toRadians(rotation.getY()))) * moveSpeed;
        float y =(float)(Math.toRadians(rotation.getX())) *moveSpeed;
        float z =(float)(Math.cos(Math.toRadians(rotation.getY()))) * moveSpeed;

        if(Input.isKeyDown(GLFW.GLFW_KEY_A)) position = Vector3f.add(position, new Vector3f(-z,0,x));
        if(Input.isKeyDown(GLFW.GLFW_KEY_D)) position = Vector3f.add(position, new Vector3f(z,0,-x));
        if(Input.isKeyDown(GLFW.GLFW_KEY_W)) position = Vector3f.add(position, new Vector3f(-x,y,-z));
        if(Input.isKeyDown(GLFW.GLFW_KEY_S)) position = Vector3f.add(position, new Vector3f(x,0,z));
        if(Input.isKeyDown(GLFW.GLFW_KEY_LEFT_SHIFT)) moveSpeed=0.1f;
        else moveSpeed=0.05f;
        if(Input.isKeyDown(GLFW.GLFW_KEY_SPACE)) position = Vector3f.add(position, new Vector3f(0,moveSpeed,0));
        if(Input.isKeyDown(GLFW.GLFW_KEY_LEFT_CONTROL)) position = Vector3f.add(position, new Vector3f(0,-moveSpeed,0));


        float dx= (float)(newMouseX - oldMouseX);
        float dy= (float)(newMouseY - oldMouseY);

        rotation = Vector3f.add(rotation, new Vector3f(-mouseSensitivity*dy, -mouseSensitivity*dx, 0));

        oldMouseX=newMouseX;
        oldMouseY=newMouseY;
    }
}
